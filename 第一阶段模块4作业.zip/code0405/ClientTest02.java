package com.lagou.code0405;

import java.io.IOException;
import java.net.Socket;

public class ClientTest02 {
    public static void main(String[] args) {
        Socket socket = null;
        try {
            socket = new Socket("127.0.0.1", 8888);
            System.out.println(socket);
            Client user = new Client("user02",socket);
            Thread s = user.send();
            Thread r =user.receive();
            s.start();
            r.start();
            s.join();
            r.join();
            user.close();
        } catch ( InterruptedException|IOException e) {
            e.printStackTrace();
        }finally{
            if (null!=socket) {
                try {
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}