package com.lagou.code0405;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private DataInputStream in;
    private DataOutputStream out;
    private Scanner sc;
    private String user;
    private String path;

    public Client(String user, Socket socket) {
        setUser(user);
        path = createFolders("src/com/lagou/code0405/files/" + user + "/");
        try {
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());
            sc = new Scanner(System.in);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Thread send() {
        Thread s = new Thread(() -> {
            System.out.println("登陆成功");
            while (true) {
                String str = sc.next();
                try {
                    if ("/file".equalsIgnoreCase(str)) {
                        System.out.println("请输入文件名");
                        str = sc.next();
                        File f = new File(path, str);
                        if (!f.exists()) {
                            System.out.println("文件不存在");
                            continue;
                        }
                        out.writeUTF("file:" + user + ":" + String.valueOf(f.length()) + ":" + str);
                        FileInputStream input = null;
                        input = new FileInputStream(f);
                        byte[] bArr = new byte[8 * 1024];
                        int res = 0;
                        while ((res = input.read(bArr)) != -1) {
                            out.write(bArr, 0, res);
                            out.flush();
                        }
                        if (null != input) {
                            input.close();
                        }
                        System.out.println("文件发送成功");

                    } else {

                        out.writeUTF("chat:" + user + ":" + String.valueOf(str.length()) + ":" + str);
                        if ("bye".equalsIgnoreCase(str)) {
                            System.out.println("聊天结束！");
                            break;
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }

        );
        return s;
    }

    public Thread receive() {
        Thread r = new Thread(() -> {
            while (true) {
                String str = "";
                try {
                    str = in.readUTF();
                    String type = str.split(":")[0];
                    String user = str.split(":")[1];
                    int messageLen = Integer.valueOf(str.split(":")[2]);
                    String message = str.split(":")[3];
                    if ("chat".equalsIgnoreCase(type)) {
                        if ("bye".equalsIgnoreCase(message)) {
                            break;
                        }
                        System.out.println(user + ":" + message);
                    }
                    if ("file".equalsIgnoreCase(type)) {
                        if (this.user.equals(user)) {
                            continue;
                        }
                        System.out.println("收到"+user+"的文件:"+message);
                        File f = new File(path, message);
                        FileOutputStream output = null;
                        output = new FileOutputStream(f);
                        byte[] bArr = new byte[8 * 1024];
                        int res = 0;
                        while (true) {
                            res = in.read(bArr, 0, bArr.length);
                            output.write(bArr, 0, res);
                            output.flush();
                            if (f.length()==messageLen) {
                                break;
                            }
                        }
                        if (null != output) {
                            output.close();
                        }

                        
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        });
        return r;
    }

    public void close() {
        if (null != in) {

            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (null != out) {

            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (null != sc) {

            sc.close();
        }

    }

    public String createFolders(String path) {
        File folders = new File(path);
        if (!folders.exists()) {
            folders.mkdirs();
        }
        return folders.getAbsolutePath();
    }

}