package com.lagou.code0405;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
    public static void main(String[] args) {
        Server s = new Server(8888);
        s.begin();

    }

    private ServerSocket ss = null;
    private Socket s = null;
    private List<Socket> socketList = new ArrayList<>();
    private String path;

    public Server(int port) {
        path = createFolders("src/com/lagou/code0405/files/server/");
        try {
            ss = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void begin() {
        System.out.println("等待客户端的连接请求...");
        try {
            while (true) {
                s = ss.accept();
                socketList.add(s);
                System.out.println("客户端" + s.getInetAddress() + "连接成功！");
                task(s);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != ss) {
                try {
                    ss.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public void task(Socket socket) {
        new Thread(() -> {
            DataInputStream in = null;
            DataOutputStream out = null;
            try {
                in = new DataInputStream(socket.getInputStream());
                out = new DataOutputStream(socket.getOutputStream());
                while (true) {
                    String str = in.readUTF();
                    System.out.println("客户端" + s.getInetAddress() +": "+ str);
                    String type = str.split(":")[0];
                    int messageLen = Integer.valueOf(str.split(":")[2]);
                    String message = str.split(":")[3];
                    if ("chat".equalsIgnoreCase(type)) {
                        for (Socket s : socketList) {
                            DataOutputStream outAll = new DataOutputStream(s.getOutputStream());
                            outAll.writeUTF(str);
                        }
                        if ("bye".equalsIgnoreCase(message)) {
                            System.out.println("客户端" + s.getInetAddress() + "已下线！");
                            break;
                        }
                    }
                    if ("file".equalsIgnoreCase(type)) {
                        System.out.println("开始接收文件");
                        File f = new File(path, message);
                        FileOutputStream output = null;
                        output = new FileOutputStream(f);
                        byte[] bArr = new byte[8 * 1024];
                        int res = 0;
                        System.out.println("开始写入文件");
                        System.out.println("文件长度为" + messageLen);
                        while (true) {
                            res = in.read(bArr, 0, bArr.length);
                            output.write(bArr, 0, res);
                            output.flush();
                            System.out.println("已经写入:" + f.length());
                            if (f.length() == messageLen) {
                                System.out.println("文件接收完毕");
                                break;
                            }
                        }
                        if (null != output) {
                            output.close();
                        }
                        for (Socket s : socketList) {
                            if (s.equals(socket)) {
                                continue;
                            }
                            DataOutputStream outAll = new DataOutputStream(s.getOutputStream());
                            outAll.writeUTF(str);
                            f = new File(path, message);
                            out.writeUTF(str);
                            FileInputStream input = null;
                            input = new FileInputStream(f);
                            while ((res = input.read(bArr)) != -1) {
                                outAll.write(bArr, 0, res);
                                outAll.flush();
                            }
                            if (null != input) {
                                input.close();
                            }
                        }
                        System.out.println("文件转发完毕");
                    }

                }
                socketList.remove(socket);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (null != in) {

                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (null != out) {

                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
        ;

    }

    public String createFolders(String path) {
        File folders = new File(path);
        if (!folders.exists()) {
            folders.mkdirs();
        }
        return folders.getAbsolutePath();
    }
}