package com.lagou.code0404;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TheServer {
    public static void main(String[] args) {
        ServerSocket ss = null;
        Socket s = null;
        ObjectInputStream in = null;
        ObjectOutputStream out = null;

        try {
            ss = new ServerSocket(8888);
            System.out.println("等待连接");
            s = ss.accept();
            in = new ObjectInputStream(s.getInputStream());
            UserMessage userMessage = (UserMessage) in.readObject();
            if ( "admin".equals(userMessage.getUser().getName()) 
            && "123456".equals(userMessage.getUser().getPassword() )) {
                userMessage.setType("success");
            } else {
                userMessage.setType("fail");
            }
            System.out.println(userMessage.getType());
            out = new ObjectOutputStream(s.getOutputStream());
            out.writeObject(userMessage);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (null != out) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != s) {
                try {
                    s.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null != ss) {
                try {
                    ss.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }
}