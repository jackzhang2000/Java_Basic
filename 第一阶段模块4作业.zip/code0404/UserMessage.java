package com.lagou.code0404;

import java.io.Serializable;

public class UserMessage implements Serializable {
    private static final long serialVersionUID = -3461064375093014549L;
    private String type;
    private User user;

    UserMessage(String type, User user) {
        setType(type);
        setUser(user);
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}