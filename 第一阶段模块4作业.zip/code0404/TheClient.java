package com.lagou.code0404;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class TheClient {
    public static void main(String[] args) {
        Socket s = null;
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
        String name = "admin";
        String password = "123456";

        try {
            s = new Socket("127.0.0.1", 8888);
            System.out.println("连接成功");
            UserMessage userMessage = new UserMessage("check", new User(name, password));
            System.out.println("用户名："+ name + "密码："+ password);
            out = new ObjectOutputStream(s.getOutputStream());
            out.writeObject(userMessage);

            in = new ObjectInputStream(s.getInputStream());
            userMessage = (UserMessage)in.readObject();
            if ("success".equals(userMessage.getType())) {

                System.out.println("登陆成功");
            }else{
                System.out.println("登陆失败");
            }
        } catch (IOException |ClassNotFoundException e) {
            e.printStackTrace();
        } finally{
            if (null!=in) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null!=out) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (null!=s) {
                try {
                    s.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        
    }
}