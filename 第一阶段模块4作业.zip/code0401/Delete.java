package com.lagou.code0401;

import java.util.List;
import java.util.Scanner;

public class Delete {

    public static void deleteStudent(Scanner sc, List<Student> listStudents) {
        System.out.println("输入需要删除的id");
        int id = sc.nextInt();
        for (Student student : listStudents) {
            int index = listStudents.indexOf(student);
            if (id == student.getId()) {
                listStudents.remove(index);
                System.out.printf("%d删除成功\n", student.getId());

            }
        }

    }
}