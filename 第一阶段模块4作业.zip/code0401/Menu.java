package com.lagou.code0401;

public class Menu {

    public static void getMenu() {
        String menu =  "1、增加学生信息；\n2、查询学生信息；\n3、删除学生信息；\n4、修改学生信息；\n5、打印所有学生；\n0、退出；\n";
        System.out.println("=================\n"+menu+"=================");

    }
}