package com.lagou.code0401;

public class MainTest {
    public static void main(String[] args) {
        try {
            Main.getStart();
        } catch (AgeException|IdException e) {
            e.printStackTrace();
        }
    }
}