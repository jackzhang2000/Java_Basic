package com.lagou.code0401;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void getStart() throws AgeException, IdException {
        List<Student> listStudents = null;

        File txt = new File("listStudents.txt");
        if (txt.exists()) {
            listStudents = ReadList.readList();
        }else{
            listStudents = new LinkedList<>();
        }

        Scanner sc = new Scanner(System.in);
        int flag;

        outer:while (true) {
            Menu.getMenu();
            flag = sc.nextInt();
            switch (flag) {
                case 1:
                    // 添加学生
                    Add.addStudent(sc, listStudents);
                    break;
                case 2:
                    // 查找学生并打印
                    Print.printStudent(Search.seachStudent(sc, listStudents));
                    break;
                case 3:
                    // 删除学生
                    Delete.deleteStudent(sc, listStudents);
                    break;
                case 4:
                    // 修改学生信息
                    Change.changeStudent(sc, Search.seachStudent(sc, listStudents));
                    break;
                case 5:
                    // 打印所有学生
                    Print.printStudents(listStudents);
                    break;
                case 0:
                    // 退出系统
                    System.out.println("正在退出系统...");
                    WriteList.writeList(listStudents);
                    break outer;
                default:
                    System.out.println("请重新选择");
                    break;
            }
        }
        sc.close();

    }
}