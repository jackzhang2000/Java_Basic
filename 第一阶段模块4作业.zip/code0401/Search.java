package com.lagou.code0401;

import java.util.List;
import java.util.Scanner;

public class Search {

    public static Student seachStudent(Scanner sc, List<Student> listStudents) {
        System.out.println("输入id");
        int id = sc.nextInt();
        for (Student student : listStudents) {
            if (id == student.getId()) {
                return student;

            }
        }
        return null;

    }

    
}