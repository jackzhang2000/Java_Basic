package com.lagou.code0401;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;
public class ReadList {
    @SuppressWarnings("unchecked")
    public static List<Student> readList() {
        ObjectInputStream in = null;
        List<Student> listStudents =null;

        try {
            in = new ObjectInputStream(new FileInputStream("listStudents.txt"));
            Object obj = in.readObject();
            listStudents = (List<Student>)obj;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (null != null) {
                try {
                    in.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return listStudents;
    }
}