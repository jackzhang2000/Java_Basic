package com.lagou.code0401;

import java.util.List;

public class Print {

    public static void printStudents(List<Student> listStudents) {
        System.out.println("打印所有学生信息");
        for (Student student : listStudents) {
            System.out.println(student);
        }
    }

    public static void printStudent(Student s){
        if (null == s) {
            System.out.println("无对象");

        } else {
            System.out.println("搜索成功" + s);
        }
    }
}