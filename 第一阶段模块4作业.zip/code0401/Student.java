package com.lagou.code0401;

import java.io.Serializable;
import java.util.Objects;

public class Student implements Serializable {
    private static final long serialVersionUID = 3556670203632481549L;
    private String name;
    private int id;
    private int age;

    Student(int id, String name, int age) throws AgeException, IdException {
        setId(id);
        setName(name);
        setAge(age);
    }

    public void setAge(int age) throws AgeException {
        if (age <= 0) {
            throw new AgeException("年龄小于0");
        } else {

            this.age = age;
        }
    }

    public void setId(int id) throws IdException {
        if (id < 0) {
            throw new IdException("id小于0");
        } else {

            this.id = id;
        }
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || this.getClass() != obj.getClass())
            return false;
        Student b = (Student) obj;
        return id == b.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "id：" + id + ", name：'" + name + "',age：" + age;
    }
}