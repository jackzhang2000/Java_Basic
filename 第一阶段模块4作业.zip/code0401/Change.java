package com.lagou.code0401;

import java.util.Scanner;

public class Change {

    public static void changeStudent(Scanner sc, Student student) throws AgeException, IdException {
        if (null == student) {
            System.out.println("无对象");
            return;
        }
        System.out.println("输入id");
        int id = sc.nextInt();
        System.out.println("输入姓名");
        String name = sc.next();
        System.out.println("输入年龄");
        int age = sc.nextInt();
        student.setId(id);
        student.setAge(age);
        student.setName(name);
        System.out.println("修改成功！");
    }
}