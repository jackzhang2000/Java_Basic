package com.lagou.code0401;

public class AgeException extends Exception {

    private static final long serialVersionUID = -2749056776334023828L;

    public AgeException(String s) {
        super(s);
    }
}