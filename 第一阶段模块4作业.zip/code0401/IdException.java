package com.lagou.code0401;

public class IdException extends Exception{

    private static final long serialVersionUID = -2261391088026045074L;

    public IdException(String s) {
        super(s);
    }
}