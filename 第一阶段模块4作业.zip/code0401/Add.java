package com.lagou.code0401;

import java.util.List;
import java.util.Scanner;

public class Add {
    public static void addStudent(Scanner sc, List<Student> listStudents) throws AgeException, IdException {
        System.out.println("输入id");
        int id = sc.nextInt();
        System.out.println("输入姓名");
        String name = sc.next();
        System.out.println("输入年龄");
        int age = sc.nextInt();
        Student newStudent = new Student(id, name, age);
        boolean flag = listStudents.contains(newStudent);
        if (flag) {
            System.out.printf("学号%d已经存在，添加失败\n", id);

        } else {
            listStudents.add(newStudent);
            System.out.printf("%s添加成功\n", name);
        }
    }
}