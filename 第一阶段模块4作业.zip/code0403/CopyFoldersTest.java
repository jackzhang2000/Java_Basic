package com.lagou.code0403;

import com.lagou.code0402.CreateFoldersAndFilesTest;

public class CopyFoldersTest {
    public static void main(String[] args) {
        CreateFoldersAndFilesTest.createFoldersAndFiles();
        CopyFolders.copyFolders("./目录1/", "./目录copy/");
    }
}