package com.lagou.code0403;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CopyFolders {
    public static void copyFolders(String oldPath, String newPath) {

        File oldFolder = new File(oldPath);
        File newFolder = new File(newPath);

        if (!oldFolder.exists()) {
            System.out.println("复制的文件夹不存在");
            return;
        }

        if (!newFolder.exists()) {
            newFolder.mkdirs();
            System.out.println(newPath+ "复制成功");
        }
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        for (File f : oldFolder.listFiles()) {
            executorService.submit(() -> {
                if (f.isFile()) {
                    CopyFile.copyFile(f.getAbsolutePath(), newFolder.getAbsolutePath() + "/" + f.getName());
                    System.out.println(f.getName() + "复制成功");
                } else {
                    CopyFolders.copyFolders(f.getAbsolutePath(), newFolder.getAbsolutePath() + "/" + f.getName());
                }
                return null;
            });
        }
        executorService.shutdown();

    }
}