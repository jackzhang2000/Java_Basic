package com.lagou.code0402;

import java.io.File;

public class DeleteAll {
    public static void deleteAll(String path) {

        File folders = new File(path);
        if (!folders.exists()) {
            System.out.println("目录不存在");
            return;
        }
        if (0 == folders.length()) {
            folders.delete();
            System.out.println(folders.getName() + "被删除了！");
            return;
        }
        for (File f : folders.listFiles()) {
            if (f.isFile()) {
                f.delete();
                System.out.println(f.getName() + "被删除了！");
            } else {
                DeleteAll.deleteAll(f.getAbsolutePath());
            }
        }
        folders.delete();
        System.out.println(folders.getName() + "被删除了！");
    }
}