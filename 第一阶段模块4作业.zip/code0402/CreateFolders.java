package com.lagou.code0402;

import java.io.File;

public class CreateFolders {

    public static void createFolders(String path) {
        File f = new File(path);
        if (!f.exists()) {
            f.mkdirs();
            System.out.println("成功创建目录："+path);

        }
    }

}