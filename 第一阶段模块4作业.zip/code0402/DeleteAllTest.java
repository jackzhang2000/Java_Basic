package com.lagou.code0402;

import java.util.concurrent.TimeUnit;

public class DeleteAllTest {
    public static void main(String[] args) {
        CreateFoldersAndFilesTest.createFoldersAndFiles();
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        DeleteAll.deleteAll("./task04/code0402/目录1/");
    }
}