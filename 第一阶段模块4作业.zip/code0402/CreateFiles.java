package com.lagou.code0402;

import java.io.File;
import java.io.IOException;

public class CreateFiles {
    public static void createFiles(String path,String name) {
        File f = new File(path,name);
        if (!f.exists()) {
            try {
                f.createNewFile();
                System.out.println("成功创建文件："+name);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}