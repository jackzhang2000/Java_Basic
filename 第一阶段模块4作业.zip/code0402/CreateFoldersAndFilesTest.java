package com.lagou.code0402;

public class CreateFoldersAndFilesTest {

    public static void createFoldersAndFiles(){
        String[] dirs = new String[]{
                "./task04/code0402/目录1/",
                "./task04/code0402/目录1/目录1.1/",
                "./task04/code0402/目录1/目录1.1/目录1.1.1/",
                "./task04/code0402/目录1/目录1.2/",
                "./task04/code0402/目录1/目录1.2/目录1.2.1/",
                "./task04/code0402/目录1/目录1.2/目录1.2.2/"
        };

        String[] files = new String[]{
                "test1.txt",
                "test1.1.txt",
                "test1.1.1.txt",
                "test1.2.txt",
                "test1.2.1.txt",
                "test1.2.2.txt",
        };
        int i=0;
        while(i<6){
            CreateFolders.createFolders(dirs[i]);
            CreateFiles.createFiles(dirs[i], files[i]);
            i++;
        }
    }

}