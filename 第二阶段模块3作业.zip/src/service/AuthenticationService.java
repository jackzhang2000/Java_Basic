package service;

import domain.UserBean;
import util.DataUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "AuthenticationService")
public class AuthenticationService extends HttpServlet {
    private static final long serialVersionUID = 1732114687029768994L;
    private final DataUtil dataUtil = DataUtil.getInstance();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String user = request.getParameter("user");
        String password = request.getParameter("password");
        System.out.println("=========login=========");
        System.out.println("user=" + user + " password=" + password);
        UserBean userBean = dataUtil.searchData(user);
        if (userBean != null && userBean.getPassword().equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            // 设置session有效时间
            session.setMaxInactiveInterval(600);
            //认证通过转到/add
            request.setAttribute("isAlert",true);
            request.setAttribute("alter","登陆成功");
            request.getRequestDispatcher("/add.do").forward(request, response);
            System.out.println("登陆成功");
        } else {
            //认证不通过回到/login
            request.setAttribute("isAlert",true);
            request.setAttribute("alter","登陆失败");
            request.getRequestDispatcher("/login").forward(request, response);
            System.out.println("登陆失败");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
