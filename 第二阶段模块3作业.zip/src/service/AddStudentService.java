package service;

import domain.StudentBean;
import util.DataUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@WebServlet(name = "AddStudentService")
public class AddStudentService extends HttpServlet {
    private static final long serialVersionUID = 1778212290439813227L;
    private final DataUtil dataUtil = DataUtil.getInstance();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        StudentBean studentBean = new StudentBean();
        studentBean.setNum(request.getParameter("num"));
        studentBean.setName(request.getParameter("name"));
        studentBean.setSex(request.getParameter("sex"));
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            studentBean.setDate(simpleDateFormat.parse(request.getParameter("date")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println("=========AddStudent=========");
        System.out.println(studentBean);
        boolean b = dataUtil.addData(studentBean);
        System.out.println(b?"success":"fail");

        request.setAttribute("isAlert",true);
        request.setAttribute("alter",b?"success":"fail");

        request.getRequestDispatcher("/add.do").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/add.do").forward(request, response);
    }
}
