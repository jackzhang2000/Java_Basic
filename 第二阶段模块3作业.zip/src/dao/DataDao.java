package dao;

import java.util.List;

public interface DataDao <T>{
    boolean addData(T obj);

    boolean deleteData(T obj);

    List<T> searchData(T obj);

    boolean editData(T obj);
}
