package test;

import domain.StudentBean;
import domain.UserBean;
import org.junit.Test;
import util.DataUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class DataUtilTest {
    private final DataUtil dataUtil = DataUtil.getInstance();

    /**
     * 测试添加一个学生数据
     * */
    @Test
    public void addStudentTest() throws ParseException {
        StudentBean studentBean = new StudentBean();
        studentBean.setNum("2002");
        studentBean.setName("test2002");
        studentBean.setSex("0");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        studentBean.setDate(simpleDateFormat.parse("2020-11-12"));
        boolean b = dataUtil.addData(studentBean);
        System.out.println(b?"success":"fail");
    }
    /**
     * 测试查询所有学生
     * */
    @Test
    public void searchStudentsTest(){
        List<StudentBean> studentBeans = dataUtil.searchData();
        for (StudentBean s:studentBeans
             ) {
            System.out.println(s);
        }

    }
    /**
     * 测试查询用户
     * */
    @Test
    public void searchUserTest(){
        UserBean user = dataUtil.searchData("admin");
        System.out.println(user);
    }

}
