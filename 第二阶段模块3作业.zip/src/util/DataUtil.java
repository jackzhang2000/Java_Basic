package util;

import dao.DataDao;
import domain.StudentBean;
import domain.UserBean;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import java.sql.SQLException;
import java.util.List;


public class DataUtil implements DataDao<StudentBean> {
    private final QueryRunner queryRunner = new QueryRunner(DruidUtil.getDataSource());

    private static class SingleDataUtil {
        private static final DataUtil DATA_UTIL = new DataUtil();
    }

    private DataUtil() {
    }

    public static DataUtil getInstance() {
        return SingleDataUtil.DATA_UTIL;
    }

    /**
     * 添加学生数据，添加成功则返回true
     *
     * @param obj StudentBean对象
     * @return boolean
     */
    @Override
    public boolean addData(StudentBean obj) {
        String sql = "INSERT INTO task07.student(num,name, sex, date) VALUES(?,?,?,?)";
        try {
            queryRunner.update(sql, obj.getNum(), obj.getName(), obj.getSex(), obj.getDate());
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteData(StudentBean obj) {
        return false;
    }


    @Override
    public List<StudentBean> searchData(StudentBean obj) {
        return null;
    }

    /**
     * 查询所有学生信息
     *
     * @return List<StudentBean>对象
     */
    public List<StudentBean> searchData() {
        String sql = "SELECT num,name,sex,date FROM task07.student;";
        List<StudentBean> query = null;
        try {
            query = queryRunner.query(sql, new BeanListHandler<StudentBean>(StudentBean.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return query;
    }

    /**
     * 通过姓名去查询用户信息，找不到则返回null
     *
     * @param name 用户姓名
     * @return UserBean对象或者null
     */
    public UserBean searchData(String name) {
        String sql = "SELECT name,password FROM task07.user WHERE name=?";
        UserBean query = null;
        try {
            query = queryRunner.query(sql, new BeanHandler<UserBean>(UserBean.class), name);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return query;
    }

    @Override
    public boolean editData(StudentBean obj) {
        return false;
    }
}
