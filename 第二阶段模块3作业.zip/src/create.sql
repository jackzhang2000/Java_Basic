DROP DATABASE IF EXISTS task07;
CREATE DATABASE IF NOT EXISTS task07 DEFAULT CHARACTER SET utf8mb4 DEFAULT COLLATE utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS task07.student
(
    id   INT(11) PRIMARY KEY AUTO_INCREMENT,
    num  VARCHAR(10) COMMENT '学号',
    name VARCHAR(10) DEFAULT NULL COMMENT '姓名',
    sex  CHAR(1)     DEFAULT NULL COMMENT '性别',
    date DATE        DEFAULT NULL COMMENT '出生日期'
);

CREATE TABLE IF NOT EXISTS task07.user
(
    id       INT(11) PRIMARY KEY AUTO_INCREMENT,
    name     VARCHAR(10) NOT NULL,
    password VARCHAR(10) NOT NULL
);

INSERT INTO
    task07.student(num, name, sex, date)
VALUES
    ('1001', '小明', 1, '2010-02-02'),
    ('1002', '小红', 0, '2010-11-23'),
    ('1003', '小林', 1, '2010-07-20'),
    ('1004', '小张', 1, '2010-12-10')
;

INSERT INTO
    task07.user(name, password)
VALUES
    ('teacher', '1'),
    ('admin', '1')
;

SELECT *
FROM
    task07.student;
SELECT *
FROM
    task07.user;