package com.lagou.common;

public class Const {

    public static final  String CURRENT_USER="currentUser";
    public static final String USERNAME = "username";
    public static final String EMAIL ="email";
    public static final String[] INDUSTRY = {"销售","服务业","生产制造"};
    public static final String START_DATE ="2020-06-04 00:00:00";
    public static final String END_DATE ="2020-06-09 23:23:59";
    public static final String[] DATE_TIME = {"2020-06-04","2020-06-05","2020-06-06","2020-06-07","2020-06-08","2020-06-09"};
}
