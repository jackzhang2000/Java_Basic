package com.lagou.homework;
import javafx.beans.property.ReadOnlyBooleanWrapper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/*
* 从本类目录下读取一个二维数组，维度用常量存放
* 实现所有元素的累加和打印
* 实现左上角到右下角元素的累加和打印
* 实现右下角到左下角所有元素的累加和并打印
*
* @author Jack Zhang
* @Created on Aug.20, 2020
* */

public class TwoDimArray {

    private static final int ROW_CONSTANT = 16;
    private static final int COL_CONSTANT = 16;

    public static void main(String[] args) {

        //读取input_array文件
        File file = new File(TwoDimArray.class.getResource("input_array.txt").getFile());
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            //初始化数组存放文件内容
            int[][] inputArray = new int[ROW_CONSTANT][COL_CONSTANT];

            //循环读取文件内容
            for (int i = 0; i < ROW_CONSTANT; i++){
                //去除前后多余空格
                String[] tmp = reader.readLine().trim().split(" ");
                for (int j = 0;j < COL_CONSTANT;j++){
                    inputArray[i][j] = Integer.parseInt(tmp[j]);
                }
            }

            //循环显示读取的数组
            System.out.println("读取的数组如下：");
            for (int i = 0; i < ROW_CONSTANT; i++){
                for (int j = 0; j < COL_CONSTANT; j++){
                    System.out.print(inputArray[i][j] + " ");
                }
                System.out.println();
            }
            System.out.println();

            System.out.println("从第一行到最后一行的计算结果为：");
            for (int i = 0; i < ROW_CONSTANT; i++){
                int sum = 0;
                for (int j = 0;j < COL_CONSTANT;j++){
                    sum += inputArray[i][j];
                }
                System.out.print(sum + " ");
            }
            System.out.println();

            System.out.println("从第一列到最后一列的计算结果为：");
            for (int i = 0; i < ROW_CONSTANT; i++){
                int sum = 0;
                for (int j = 0;j < COL_CONSTANT;j++){
                    sum += inputArray[j][i];
                }
                System.out.print(sum + " ");
            }
            System.out.println();

            int sum, i, j;
            System.out.println("从左上角到右下角累加和为：");
            //初始化变量, 下标i==j 下标由小到大，一直相加
            sum = 0;
            i = 0;
            j = 0;
            while (i < ROW_CONSTANT) {
                sum = sum + inputArray[j][i];
                i++;
                j++;
            }
            System.out.println(sum);

            System.out.println("从右上角到左下角累加和为：");
            //初始化变量, 下标i由小到大，下标j由大到小，一直相加
            sum = 0;
            i = 0;
            j = 15;
            while (i < ROW_CONSTANT) {
                sum = sum + inputArray[j][i];
                i++;
                j--;
            }
            System.out.println(sum);

        }catch(Exception e) {
            System.out.println("读取文件异常");

        }



    }
}
