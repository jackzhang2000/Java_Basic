package com.lagou.homework.card;

public enum typeEnum {
    //大卡，小卡，微型卡
    BIG("大卡"), SMALL("小卡"), MICRO("微型卡");

    private String name;//手机卡类型

    typeEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
