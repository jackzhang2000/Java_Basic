package com.lagou.homework.card;

//（1）实现手机卡类 特征：卡类型、卡号、用户名、密码、账户余额、通话时长(分钟)、上网流量 行为：显示（卡号 + 用户名 + 当前余额）
public class SIMCard {
    //特征
    private typeEnum cardType; //sim卡类型
    private String cardNumber; //卡号
    private String userName;//用户名
    private String password;//密码
    private int accountBalance;//账户余额
    private int CallDuration;//通话时长
    private int MobileInternetData;//上网流量

    public SIMCard() {
    }

    public SIMCard(String cardNumber, String userName, int accountBalance) {
        setCardNumber(cardNumber);
        setUserName(userName);
        setAccountBalance(accountBalance);
    }

    public SIMCard(typeEnum cardType, String cardNumber, String userName, String password, int accountBalance, int callDuration, int mobileInternetData) {
        setCardType(cardType);
        setCardNumber(cardNumber);
        setUserName(userName);
        setPassword(password);
        setAccountBalance(accountBalance);
        setCallDuration(callDuration);
        setMobileInternetData(mobileInternetData);
    }

    public void show(){
        System.out.println(this.userName + "的手机。手机号码为" + this.cardNumber +  "账户余额为：" + this.accountBalance);
    };

    public typeEnum getCardType() {
        return cardType;
    }

    public void setCardType(typeEnum cardType) {
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(int accountBalance) {
        this.accountBalance = accountBalance;
    }

    public int getCallDuration() {
        return CallDuration;
    }

    public void setCallDuration(int callDuration) {
        this.CallDuration = callDuration;
    }

    public int getMobileInternetData() {
        return MobileInternetData;
    }

    public void setMobileInternetData(int MobileInternetData) {
        this.MobileInternetData = MobileInternetData;
    }

}
