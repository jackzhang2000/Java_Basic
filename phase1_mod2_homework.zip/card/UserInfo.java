package com.lagou.homework.card;
//用户消费信息类 特征：统计通话时长、统计上网流量、每月消费金额
public class UserInfo {
    //特征
    private int callDuration;//通话时长(分钟)
    private int mobileInternetData;//上网流量
    private int monthlyCharges;//每月消费金额

    public UserInfo() {}

    public UserInfo(int callDuration, int mobileInternetData, int monthlyCharges) {
        this.callDuration = callDuration;
        this.mobileInternetData = mobileInternetData;
        this.monthlyCharges = monthlyCharges;
    }

    //getter and setter

    public int getCallDuration() {   return callDuration;    }

    public void setCallDuration(int callDuration) { this.callDuration = callDuration;  }

    public int getMobileInternetData() {  return mobileInternetData; }

    public void setMobileInternetData(int mobileInternetData) {   this.mobileInternetData = mobileInternetData; }

    public int getMonthlyCharges() {  return monthlyCharges; }

    public void setMonthlyCharges(int monthlyCharges) {  this.monthlyCharges = monthlyCharges; }

}
