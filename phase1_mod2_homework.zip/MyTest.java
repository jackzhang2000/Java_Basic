package com.lagou.homework;
import com.lagou.homework.card.SIMCard;
import com.lagou.homework.card.UserInfo;
import com.lagou.homework.card.typeEnum;
import com.lagou.homework.plan.CallService;
import com.lagou.homework.plan.NetworkServiceImpl;
import com.lagou.homework.plan.NetworkService;
import com.lagou.homework.plan.Package;
import com.lagou.homework.plan.CallServiceImpl;

/*
* 测试类使用多态格式分别调用各个实现类和接口中的方法，方法体中打印一句话进行功能模拟即可。*/

public class MyTest {
    public static void main(String[] args) {
        //初始化SIM卡
        SIMCard simCard = new SIMCard();
        simCard.setUserName("Jack Zhang");
        simCard.setPassword("1234");
        simCard.setAccountBalance(200);
        simCard.setCardNumber("15011111111");
        simCard.setCardType(typeEnum.BIG);
        simCard.setCallDuration(60);
        simCard.setMobileInternetData(500);
        simCard.show();

        //初始化通话套餐，通话时长：60，短信条数：20， 每月资费30
        CallServiceImpl myCAll = new CallServiceImpl(simCard.getCallDuration(), 20, 30);
        //初始化上网套餐，上网流量MB：500，每月资费20
        NetworkServiceImpl myNetwork = new NetworkServiceImpl(simCard.getMobileInternetData(), 20);

        showPackageInfo(myCAll);
        showPackageInfo(myNetwork);

        //初始化用户消费信息
        UserInfo userInfo = new UserInfo();
        //统计通话时长，上网流量，每月消费金额=通话套餐月费+上网套餐月费
        userInfo.setCallDuration(30);
        userInfo.setMobileInternetData(100);
        userInfo.setMonthlyCharges(50);
        //服务接口的引用
        CallService callService;
        NetworkService networkService;
        callService = myCAll;
        networkService = myNetwork;
        //开启打电话服务
        callService.call(userInfo.getCallDuration(), simCard);
        //开启上网服务
        networkService.connect(userInfo.getMobileInternetData(), simCard);
        //查看套餐信息
        showPackageInfo(myCAll);
        showPackageInfo(myNetwork);
    }

    /*显示套餐信息*/
    static void showPackageInfo(Package myPackage) {
        myPackage.show();
    }
}
