package com.lagou.homework;
import javafx.beans.property.ReadOnlyBooleanWrapper;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
/*
 * 编程实现控制台版并支持两人对战的五子棋游戏。
 *（1）绘制棋盘 - 写一个成员方法实现
 *（2）提示黑方和白方分别下棋并重新绘制棋盘 - 写一个成员方法实现。
 *（3）每当一方下棋后判断是否获胜 - 写一个成员方法实现。
 *（4）提示： 采用二维数组来模拟并描述棋盘，棋盘如下：
 *
 * @author Jack Zhang
 * @Created on Aug.20, 2020
 * */

public class ChessGame {
    private static final int MAX_ROW = 17;
    private static final int MAX_COL = 17;
    private static final char BLACK_CHAR;
    private static final char WHITE_CHAR;
    private static final char BOARD_EMPTY_MARK;

    private boolean blackTurn = true;//true时，黑方下棋

    private final char[][] chessBoard;//五子棋盘

    private int turnCounter;

    static {

        BLACK_CHAR = 9688;//9688是黑色色块的编码
        WHITE_CHAR = 9617;//白棋色块的编码
        BOARD_EMPTY_MARK = 43;//加号的编码
    }
    //构造块，初始化棋盘
    {
        chessBoard = new char[MAX_ROW][MAX_COL];
        turnCounter = 0;
    }

    //更新回合
    public void updateBlackTurn() {
        this.blackTurn = !this.blackTurn;
    }
    //getter
    public boolean isBlackTurn() {
        return blackTurn;
    }
    //setter
    public void setBlackTurn(boolean blackTurn) {
        this.blackTurn = blackTurn;
    }

    public boolean setChessBoard(int y, int x) {
        //判断位置是否合法
        if(chessBoard[y][x] != BOARD_EMPTY_MARK) {
            System.out.println("这个位置已有棋子，请重新输入：");
            System.out.println();
            return false;
        }

        if(isBlackTurn()) {
            chessBoard[y][x] = BLACK_CHAR;
        } else {
            chessBoard[y][x] = WHITE_CHAR;
        }
        return true;
    }

    public ChessGame() {
    }
    //检查本轮是否获胜
    private boolean checkPlayerStatus (int y, int x){
        int minY = y - 4, minX = x - 4, maxY = y + 4, maxX = x + 4;
        minY = Math.max(minY, 1); minX = Math.max(minY, 1);
        maxY = Math.max(maxY, 16); maxX = Math.max(maxX, 16);

        int counter, i, j;//初始化计数器和下标
        //上下遍历
        counter = 1;
        //往上循环
        i = y - 1;
        j = x;
        while (i >= minY) {
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            i--;
        }
        //往下循环
        i = y +1;
        j = x;
        while (i <= maxY){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            i++;
        }
        //检查是否获胜
        if (counter >= 5) {
            System.out.println("Counter：" + counter);
            return true;
        }

        //左右检查；初始化计数器为1，代表本回合的棋子
        counter = 1;
        //往左循环
        i = y;
        j = x - 1;
        while (j >= minX){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            j--;
        }

        //往右循环
        i = y;
        j = x + 1;
        while (j <= maxX){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            j++;
        }
        //是否获胜
        if (counter >= 5) {
            System.out.println("左右检查 Counter：" + counter);
            return true;
        }

        //右上左下的检查
        counter = 1;
        //往右上循环
        i = y - 1;
        j = x + 1;
        while (i >= minY && j <= maxX){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            i--;
            j++;
        }
        //往左下循环
        i = y + 1;
        j = x - 1;
        while (i <= maxX && j >= minX){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            i++;
            j--;
        }
        //是否获胜
        if (counter >= 5) {
            System.out.println("右上左下的检查 Counter：" + counter);
            return true;
        }

        //右下左上的检查
        counter = 1;
        //往右下循环
        i = y + 1;
        j = x + 1;
        while (i <= maxY && j <=maxX){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            i++;
            j++;
        }

        //往左上循环
        i = y - 1;
        j = x - 1;
        while (i >= minX && j >= minY){
            if (chessBoard[y][x] == chessBoard[i][j]) {
                counter++;
            } else {
                break;
            }
            i--;
            j--;
        }
        //是否获胜
        if (counter >= 5) {
            System.out.println("右下左上的检查 Counter：" + counter);
            return true;
        }
        /*本回合无玩家获胜*/
        System.out.println("Counter：" + counter);
        return false;
    }

    /*把棋子放到棋盘的过程*/
    private boolean playChess() {
        if (isBlackTurn()) {
            System.out.println("黑方回合：");
        } else {
            System.out.println("白方回合：");
        }
        //读取用户的输入
        Scanner sc = new Scanner(System.in);
        int y =0, x =0;
        try {
            y = Integer.parseInt(sc.next().trim(), 16);
            x = Integer.parseInt(sc.next().trim(), 16);
            //判断输入的位置是否在棋盘范围
            if (y < 0 || y >15 || x <0 || x > 15) {
                System.out.println("输入错误，请重新输入0到f之间的值：");
                System.out.println("0 1 2 3 4 5 6 7 8 9 a b c d e f");
            } else {
                //更新棋盘
                y++; x++;
                if (setChessBoard(y, x)) {
                    turnCounter++;
                    System.out.println("第 " + turnCounter + " 回合");
                    outputBoard();
                    System.out.println();

                    if (checkPlayerStatus(y, x)) {
                        return true;
                    }
                    //更新回合
                    updateBlackTurn();
                    return false;
                }
            }
        } catch (NumberFormatException e) {
            System.out.println();
            System.out.println("输入错误，请重新输入0到f之间的值：");
            System.out.println("0 1 2 3 4 5 6 7 8 9 a b c d e f");
            System.out.println();
        }
        return false;
    }
    //输出绘制棋盘
    private void outputBoard() {
        for (int i =0; i < MAX_ROW; i++) {
            for (int j =0; j < MAX_COL; j++) {
                System.out.print(chessBoard[i][j] + " ");
            }
            System.out.println();
        }
    }
    /*初始化棋盘，并输出到控制台*/
    private void initializeChessBoard() {

        chessBoard[0][0] = 32; //空格的ASCII码

        for (int i =0; i < MAX_ROW; i++) {
            //添加 0到f的行号 列号
            chessBoard[0][i] = Integer.toHexString(i-1).charAt(0);
            chessBoard[i][0] = Integer.toHexString(i-1).charAt(0);
            for (int j =1; j < MAX_COL; j++) {
                chessBoard[i][j] = BOARD_EMPTY_MARK;
            }
        }
        //输出到控制台
        outputBoard();
    }

    public static void main(String[] args) {
        ChessGame ChessGame = new ChessGame();
        System.out.println("初始化五子棋棋盘");
        ChessGame.initializeChessBoard();
        System.out.println();
        ChessGame.setBlackTurn(true);
        System.out.println("游戏开始，请黑白双方分别输入坐标，先输入横坐标，再输入纵坐标：");
        System.out.println();

        for (;;) {
            if (ChessGame.playChess()) {
                System.out.println("游戏开始，请黑白双方分别输入坐标，先输入横坐标，再输入纵坐标：");
                System.out.println("祝贺" + (ChessGame.isBlackTurn() ? "黑方" : "白方") + "获胜");
                System.out.println("游戏结束！");
                break;
            }
        }
    }

}
