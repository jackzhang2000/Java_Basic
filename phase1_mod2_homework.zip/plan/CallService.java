package com.lagou.homework.plan;
/*（1）通话服务接口 抽象方法: 参数1: 通话分钟, 参数2: 手机卡类对象 让通话套餐类实现通话服务接口。 */
import com.lagou.homework.card.SIMCard;

public interface CallService {
    /*打电话服务，抽象接口
    * 参数：mintues通话分钟 SIMCard手机卡对象*/
    public abstract void call(int minutes, SIMCard simCard);
}
