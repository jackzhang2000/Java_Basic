package com.lagou.homework.plan;
import com.lagou.homework.card.SIMCard;

/* （2）上网服务接口 抽象方法: 参数1: 上网流量, 参数2: 手机卡类对象 让上网套餐类实现上网服务接口。*/
public interface NetworkService {

    void connect(int mobileInternetData, SIMCard simCard);
}
