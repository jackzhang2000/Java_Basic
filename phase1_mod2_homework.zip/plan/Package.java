package com.lagou.homework.plan;
/*实体类的优化 将通话套餐类和上网套餐类中相同的特征和行为提取出来组成抽象套餐类。 */
public abstract class Package {
    private int monthlyCharges;//每月资费

    public Package() {}

    public Package(int monthlyCharges) { setMonthlyCharges(monthlyCharges); }

    public abstract void show();
    /*getter and setter*/
    public int getMonthlyCharges() {
        return monthlyCharges;
    }

    public void setMonthlyCharges(int monthlyCharges) {
        this.monthlyCharges = monthlyCharges;
    }
}
