package com.lagou.homework.plan;

import com.lagou.homework.card.SIMCard;
import com.lagou.homework.plan.NetworkService;
import com.lagou.homework.plan.Package;

public class NetworkServiceImpl extends Package implements NetworkService {
    private int mobileInternetData;
    private int monthlyCharges;

    @Override
    public void connect(int mobileInternetData, SIMCard simCard) {

    }

    public NetworkServiceImpl(int mobileInternetData, int monthlyCharges) {
        this.mobileInternetData = mobileInternetData;
        this.monthlyCharges = monthlyCharges;
    }

    @Override
    public void show() {
        System.out.println("上网套餐信息如下：");
        System.out.println("剩余流量：" + this.mobileInternetData + "每月资费：" + this.monthlyCharges );
    }

}
