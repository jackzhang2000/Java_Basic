package com.lagou.homework.plan;

import com.lagou.homework.card.SIMCard;
import com.lagou.homework.plan.CallService;
import com.lagou.homework.plan.Package;

public class CallServiceImpl extends Package implements CallService {

    private int duration;
    private int messageCount;
    private int monthlyCharges;

    @Override
    public void call(int minutes, SIMCard simCard) {
    }

    public CallServiceImpl(int duration, int messageCount, int monthlyCharges) {
        this.duration = duration;
        this.messageCount = messageCount;
        this.monthlyCharges = monthlyCharges;
    }

    @Override
    public void show() {
        System.out.println("通话套餐信息如下：");
        System.out.println("剩余通话时长：" + this.duration + "剩余短信条数："+ this.messageCount + "每月资费：" + this.monthlyCharges );
    }
}
//        CallServiceImpl myCAll = new CallServiceImpl(simCard.getCallDuration(), 20, 30);